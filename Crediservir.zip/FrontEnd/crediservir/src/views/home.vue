<script>
export default {
  name: 'HomeView',
}
</script>
