<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'App',
};
</script>

<style>
/* Aquí puedes agregar estilos globales si los necesitas */
</style>
