<script>
export default {
  name: 'HomeView',  // Cambia 'Home' a 'HomeView'
}
</script>
